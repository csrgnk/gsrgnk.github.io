# Simple Static Site (No Jekyll)
This repo is a minimal starter for GitHub Pages with ONLY direct files and folders (HTML/CSS/JS).

## How to use
1. Upload everything in this folder to your GitHub repo.
2. Add a file named `.nojekyll` at the root (included here) to disable Jekyll.
3. In repo Settings → Pages:
   - Source: `Deploy from a branch`
   - Branch: `main` and `/ (root)`
4. Open `https://<your-username>.github.io/` (or your custom domain) to view.

Add more pages as `page-name.html` and link them in your nav.
